"""
The intention of this test is....
This descriptions should include the intention of the test, duration, and any prerequisites that the test needs.
"""


class TestClass(appBase):
    """
    Constructor method:

    :param param1: Description of the first parameter
    :type param1: type of the first parameter
    :param param2: The operating system that this test is going to be running in
    :type param2: string
    """
    def __init__(self, param1, param2):
        self.param1 = param1
        self.param2 = param2

    def pre_process(self):
        """
        The pre_process runs the following functions.

        Steps to execute:
            1. Step 1
            2. Step 2
        """

    def test_perform_sequence(self):
        """
        Abstract method that gets overridden by the test class that inherits from this base class
        """
        pass

    def post_process(self):
        """
        The post_process runs the following functions.

        Steps to execute:
            1. Step 1
            2. Step 2
        """

