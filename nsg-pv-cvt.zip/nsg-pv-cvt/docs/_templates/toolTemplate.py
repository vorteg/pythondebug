"""
<Tool name> wrapper. Runs <Tool name> commands.

Todo:
    * Add any to do items here

"""
import subprocess

from utils.features.logger.logger import logger


def run(*args, **kwargs):
    """
    Function that executes the given conman commands with the given parameters

    :param args: Command to execute with respective parameters
    :type args: string
    :param kwargs: Optional parameters with keywords
    :return: stdout and error code of the executed command
    """
    parameters = [PATH] + list(args)
    logger.info('Command: {0}'.format(' '.join(parameters)))
    process = subprocess.Popen(parameters, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = process.communicate()
    error_code = process.returncode
    pid = process.pid
    logger.info('stdout: {0}, stderr: {1}'.format(stdout, stderr))
    logger.info('issdcm ran with process ID {0}.'.format(pid))
    logger.info('issdcm finished with error code {0}'.format(error_code))
    return stdout, error_code


def descriptive_name_of_function():
    """
    Description of funcion

    :return: What this function returns
    """

    return "Something"

