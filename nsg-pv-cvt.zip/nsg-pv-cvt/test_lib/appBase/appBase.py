#
# INTEL CONFIDENTIAL
# Copyright 2020 Intel Corporation All Rights Reserved.
# The source code contained or described herein and all documents related
# to the source code ("Material") are owned by Intel Corporation or its
# suppliers or licensors. Title to the Material remains with Intel Corporation
# or its suppliers and licensors. The Material contains trade secrets and
# proprietary and confidential information of Intel or its suppliers and
# licensors. The Material is protected by worldwide copyright and trade secret
# laws and treaty provisions. No part of the Material may be used, copied,
# reproduced, modified, published, uploaded, posted, transmitted, distributed,
# or disclosed in any way without Intel's prior express written permission.
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#

__author__ = 'GDC Test Dev'
__copyright__ = "Copyright 2020, Intel Corporation"


from utils.features.logger.logger import logger
from utils.features.FolderManagement import FolderManagement
from utils.features.FolderManagement.FolderUtils import FolderUtils
from test_ops.drive_ops.drive_handler.drive_handler import DriveHandler
from utils.features.Settings import Settings
from tools.tools import Tools
from utils.features.reports import jsonCreator
#from tools.toolwrapper.conman import conman


class appBase(object):


    def __init__(self, *args, **kwargs):
        self.test_name = "Firmware upgrade"
        self.info_list = []
        self.results_directory = None
        self.general_tool = 'toolTest'

    def __get_tool(self):
        tl = Tools(self.general_tool).select_tool()
        return tl

    def pre_process(self):

        logger.info('--- Folder management ---')
        #obj = FolderUtils()
        #self.results_directory = obj.initialize_variables(test_name=self.test_name)

        logger.info("--- System check ---")
        #system_info = Settings.get_win_sys_info()
        #logger.debug('Hostname: {}'.format(system_info['HOSTNAME']))
        #logger.debug('Operating System: {}'.format(system_info['OS']))
        #logger.debug('Platform: {}'.format(system_info['SYSTEM_MODEL']))
        #logger.debug('Driver installed: {}'.format('...'))
        #self.info_list.append(system_info)


        logger.info("--- Get Sanity drive health check --- ")
        #######drive_dict = Settings.drives_path_dict()
        tool = self.__get_tool()
        drive_dict = tool.drives_path_dict()
        logger.debug('Drive List: {}'.format(drive_dict))
        print('\nDrive List: {}'.format(drive_dict))
        #self.info_list.append(drive_dict)
        for drive_path in drive_dict['Drives_Path']:

            info_dict = tool.drives_info_dict(drive_path)
            #self.info_list.append(info_dict)
            logger.debug('\nDrive info: {}'.format(info_dict))
            print('\nStatus device for {} is {}'.format(drive_path, info_dict['Drive_Info']))


            drive_smart_info = tool.get_smart_values(drive_path)
            logger.debug('Smart info for {}: {}'.format(drive_path, drive_smart_info))
            #self.info_list.append(drive_smart_info)

            if ('Completed successfully' in line for line in str(drive_smart_info).splitlines()):
                logger.info('Smart for {} completed successfully!'.format(drive_path))
                print('Smart for {} completed successfully!'.format(drive_path))
            else:
                logger.error('Smart for {} Failed!'.format(drive_path))
                print('Smart for {} Failed!'.format(drive_path))


        logger.info("--- Generate first report ---")
        #if not obj.gen_json_report(self.info_list, 'pre'):
        #    print('Pre report could not be created.')

        print("\nExecuting FW Upgrade Test\n")
        print('\n-----------------------------------------')
        print("\nRunning pre_process")
        print("Folder Results Created")
        print("System check (HW:, OS:) ")


    def perform_test_sequence(self):

        pass


    def post_process(self):

        logger.info('--- Post process ---')
        logger.info('--- Folder management ---')
        obj = FolderUtils()

        logger.info("--- System check ---")
        system_info = Settings.get_win_sys_info()
        logger.debug('Hostname: {}'.format(system_info['HOSTNAME']))
        logger.debug('Operating System: {}'.format(system_info['OS']))
        logger.debug('Platform: {}'.format(system_info['SYSTEM_MODEL']))
        logger.debug('Driver installed: {}'.format('...'))
        self.info_list.append(system_info)


        logger.info("--- Get Sanity drive health check --- ")
        drive_dict = Settings.drives_path_dict()
        logger.debug('Drive List: {}'.format(drive_dict))
        print('\nDrive List: {}'.format(drive_dict))
        self.info_list.append(drive_dict)
        for drive_path in drive_dict['Drives_Path']:

            info_dict = Settings.drives_info_dict(drive_path)
            self.info_list.append(info_dict)
            logger.debug('\nDrive info: {}'.format(info_dict))
            print('\nStatus device for {} is {}'.format(drive_path, info_dict['Drive_Info']['DeviceStatus']))

            drive_smart_info = conman.get_smart_values(drive_path)
            logger.debug('Smart info for {}: {}'.format(drive_path, drive_smart_info))
            self.info_list.append(drive_smart_info)

            if ('Completed successfully' in line for line in str(drive_smart_info).splitlines()):
                logger.info('Smart for {} completed successfully!'.format(drive_path))
                print('Smart for {} completed successfully!'.format(drive_path))
            else:
                logger.error('Smart for {} Failed!'.format(drive_path))
                print('Smart for {} Failed!'.format(drive_path))


        logger.info("--- Generate first report ---")
        if not obj.gen_json_report(self.info_list, 'post'):
            print('Post report could not be created.')

        logger.info("--- Generate jira report ---")
        if not Settings.write_jira_template(test_name=self.test_name, results_directory=self.results_directory):
            logger.error('Unable to create JIRA report!! Please contact DEV team')

        jsonCreator.create_test_report(test_name="FW upgrade", test_config="Sata Host", status="pass",
                                       next_steps="FW upgrade test finished")

    def run(self):
        logger.info('Running pre_process.')
        self.pre_process()
        logger.info('Running _perform_test_sequence.')
        #self.perform_test_sequence()
        logger.info('Running _post_process.')
        #self.post_process()

if __name__ == "__main__":
   appBase().run()
