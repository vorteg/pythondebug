"""
Base class for the Dummy Test. This base class includes the pre_process() and the post_process() functions, as well
as the abstract method test_perform_sequence() for it to be overridden by the test class that inherits from it (In this
case the dummyTest class).
"""
from utils.features.logger.logger import logger
from test_ops.drive_ops.drive_handler.drive_handler import DriveHandler
from tools.tools import Tools
from test_lib.appBase.appBase import appBase
from utils.features.Settings import Settings
from utils.features.reports import jsonCreator


class DummyBase(object):
    def __init__(self, platform, os):

        self.platform = platform
        self.os = os

    def pre_process(self):
        logger.info("System check")

        logger.info("Get Sanity drive health check (registers...) ")

        logger.info("Generate first report ")

        print("\nExecuting FW Upgrade Test\n")
        print('\n-----------------------------------------')
        print("\nRunning pre_process")
        print("Folder Results Created")
        print("System check ")

    def perform_test_sequence(self):
        pass


    def post_process(self):

        logger.info("Folder manipulation ")
        logger.info("Generate last report ")
        logger.info("EEV-parser(Pass Fail)* ")
        print('\n-----------------------------------------')
        print("Logs saved on Results Folder, Test Passed")
        print("Post-process successfully")

    def run(self):
        self.pre_process()
        self.perform_test_sequence()
        self.post_process()


if __name__ == "__main__":

    obj = DummyBase(platform='WFP', os='Win2019')
    obj._pre_process()
