"""
The intent of this test is to simulate the complete test flow with dummy functions.
This test will also be used to show documentation standards.
"""

from utils.features.logger.logger import logger
from test_ops.drive_ops.driveDummy.driveDummy import DriveDummy
from test_lib.appBase.dummyBase import DummyBase
from tools.tools import Tools
from utils.features.reports import jsonCreator


class DummyTest(DummyBase):

    def __init__(self, duration):
        self.duration = duration
        if self.duration == "fail":
            self.status = "fail"
        else:
            self.status = "pass"
        self.firmwarDrive = "version-ww10.1"
        super().__init__("wolfpass","Windows")


    """
    :param firmwareDrive: Description of the attribute self.firmwareDrive
    :type firmwareDrive: string, optional
    """

    def perform_test_sequence(self):
        """
        Overrides the parent function test_perform_sequence.
        This function executes the steps of the test at hand.

        Steps to execute:
            1. Create a drive object with the following attributes: tool, mode, serial number, fw version, quarch port, health status, drive path, drive index, sector_size
            2. Call the function run_obj() that will fill out the attributes of the drive object created on step 1.
            3. Select 'conman' as the tool to perform the dummy test with
            4. Perform a dummy upgrade firmware test
        """

        print('\n-----------------------------------------')
        print("Running test_perform_sequence(Test Flow)")
        logger.info("Get Drives")
        disk = DriveDummy('toolTest')
        disk.run_obj()
        fw_tool = Tools('toolTest').select_tool()
        fw_tool.fw_up_test(disk.drive_path)
        print('\n-----------------------------------------')
        print('\nDrive info')
        print("Drive Path: ", disk.drive_path)
        print("Drive Status: ", disk.status)
        print("Drive Serial: ", disk.serial)
        print("Drive index: ", disk.drive_index)

    def post_process(self):
        super().post_process()
        print(self.firmwarDrive)
        jsonCreator.create_test_report(test_name="Dummy Test", test_config="Dummy config", status=self.status,
                                       next_steps="Dummy test finished")


if __name__ == '__main__':
    DummyTest(duration="pass").run()
