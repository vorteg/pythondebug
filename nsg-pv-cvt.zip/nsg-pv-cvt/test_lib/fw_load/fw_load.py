from utils.features.reports import jsonCreator

__author__ = 'GDC Test Dev'
__copyright__ = "Copyright 2020, Intel Corporation"

from utils.features.logger.logger import logger
from test_ops.drive_ops.drive_handler.drive_handler import DriveHandler
from test_lib.appBase.appBase import appBase
from tools.tools import Tools
from utils.features.reports import jsonCreator

FWPATH = r"C:\VDV10261\VDV10261_VB1B0203_WFEM01A0.bin"

class Fw_load(appBase):
    def __init__(self, firmware):
        self.firmware = firmware
        super().__init__("wolfpass","Windows")

    def perform_test_sequence(self):
        print('\n-----------------------------------------')
        print("Running test_perform_sequence(Test Flow)")
        logger.info("Get Drives")
        disk = DriveHandler('conman').run_drive_handler_object()
        # print(disk.status, disk.drive_path)

        print('\n-----------------------------------------')
        print("FW upgrade")
        fw_tool = Tools('conman').select_tool()
        print(fw_tool.firmware_update(disk.drive_path, self.firmware))

    def post_process(self):
        super().post_process()
        jsonCreator.create_test_report(test_name="FW upgrade", test_config="Sata Host", status="pass",
                                       next_steps="FW upgrade test finished")


if __name__ == '__main__':
    #Fw_load().test_perform_sequence()
    Fw_load().run()
