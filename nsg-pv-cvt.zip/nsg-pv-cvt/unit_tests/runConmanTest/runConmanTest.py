"""
Runner that will call the conman wrapper unit tests.
"""

import argparse

from unit_tests.conmanTest import conmanTest
from utils.features.logger.logger import logger

def main():
    parser = argparse.ArgumentParser(description='Fw up/down & sidegrade')
    parser.add_argument('-dp', '--drive_paths', action="store_true", default=False,
                        help='Enable getting drive paths.')
    parser.add_argument('-ud', '--update_drive', action="store_true", default=False,
                        help='Enable update drive.')
    parser.add_argument('-di', '--drive_info', action="store_true", default=False,
                        help='Enable getting drive info.')

    args = parser.parse_args()
    print(args)

    try:
        test = conmanTest(
                drive_paths=args.drive_paths,
                update_drive=args.update_drive,
                drive_info=args.drive_info
        )
        test.run()
    except Exception as e:
        logger.error("Fail test", e)


if __name__ == "__main__":
    main()
