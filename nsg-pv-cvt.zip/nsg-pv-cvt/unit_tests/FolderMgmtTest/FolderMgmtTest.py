#
# INTEL CONFIDENTIAL
# Copyright 2020 Intel Corporation All Rights Reserved.
# The source code contained or described herein and all documents related
# to the source code ("Material") are owned by Intel Corporation or its
# suppliers or licensors. Title to the Material remains with Intel Corporation
# or its suppliers and licensors. The Material contains trade secrets and
# proprietary and confidential information of Intel or its suppliers and
# licensors. The Material is protected by worldwide copyright and trade secret
# laws and treaty provisions. No part of the Material may be used, copied,
# reproduced, modified, published, uploaded, posted, transmitted, distributed,
# or disclosed in any way without Intel's prior express written permission.
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
__author__ = 'GDC Test Dev'
__copyright__ = "Copyright 2020, Intel Corporation"

# Import Python Modules ---------------------------------------------------
import os, unittest
# Import PGKS Modules -----------------------------------------------------
from utils.features.FolderManagement import FolderManagement
from utils.features.logger.logger import logger
# Global Variables --------------------------------------------------------
results = {'Network_result':'', 'local_result':'', 'Generic_folder_result':''}

class FolderMgmtTest(object):

    def __init__(self, network=False, local=False, crt_folder=None):
        self.network = network
        self.local = local
        self.crt_folder = crt_folder
    
    def run(self):
        dirs_fldr = []
        try:
            if self.network:
                dirs_fldr.append(self.create_network_directory())
            if self.local:
                dirs_fldr.append(self.create_local_directory())
            if self.crt_folder:
                dirs_fldr.append(self.create_generic_folder())
        except Exception as e:
            logger.fatal('Test failed due: {}'.format(e))
        finally:
            logger.info('Validating tests results...')
            results = self.parse_results(dirs_fldr)
            logger.info('Test results: {}'.format(results))

    def create_network_directory(self):
        logger.info('Running network diretory creation test...')
        dirs_fldr = FolderManagement.create_results_directory_generic(network=self.network)
        if dirs_fldr:
            logger.debug('Folder created: {}'.format(dirs_fldr))
        else:
            logger.error('Something went wrong while creating directory, please find more further details in logs')
        return dirs_fldr

    def create_local_directory(self):
        logger.info('Running local diretory creation test...')
        dirs_fldr = FolderManagement.create_results_directory_generic(local=self.local)
        if dirs_fldr:
            logger.debug('Folder created: {}'.format(dirs_fldr))
        else:
            logger.error('Something went wrong while creating directory, please find more further details in logs')
        return dirs_fldr

    def create_generic_folder(self):
        logger.info('Running generic folder creation test...')
        dirs_fldr = FolderManagement.create_folder_directory_generic(folder_path=self.crt_folder)
        if dirs_fldr:
            logger.debug('Folder created: {}'.format(dirs_fldr))
        else:
            logger.error('Something went wrong while creating directory, please find more further details in logs')
        return dirs_fldr

    def create_network_local_directory(self):
        logger.info('Running local and network diretory creation test...')
        dirs_fldr = FolderManagement.create_results_directory_generic(local=self.local, network=self.network)
        if dirs_fldr:
            for index in range(len(dirs_fldr)):
                logger.debug('Folder created: {}'.format(dirs_fldr[index]))
        else:
            logger.error('Something went wrong while creating directory, please find more further details in logs')
        return dirs_fldr

    def parse_results(self, dir_fldr):
        if self.network:
            logger.info('Checking the existance of test results directory in network path...')
            for value in range(len(dir_fldr)):
                str_pth = str(dir_fldr[value])
                if str_pth.startswith('Z:'):
                    logger.debug('Network path is reported by FolderManagement module: {}'.format(dir_fldr[value]))
                    if os.path.exists(dir_fldr[value]):
                        results['Network_result'] = 'Pass'
                        break
                    else:
                        results['Network_result'] = 'Fail'
                else:
                    logger.info('keep looking for local path entries...')
        else:
            results['Network_result'] = 'Not ran'
        if self.local:
            logger.info('Checking the existance of test results directory in local path...')
            for value in range(len(dir_fldr)):
                str_pth = str(dir_fldr[value])
                if str_pth.startswith('C:'):
                    logger.debug('local path is reported by FolderManagement module: {}'.format(dir_fldr[value]))
                    if os.path.exists(dir_fldr[value]):
                        results['local_result'] = 'Pass'
                        break
                    else:
                        results['local_result'] = 'Fail'
                else:
                    logger.info('keep looking for local path entries...')
        else:
            results['local_result'] = 'Not ran'
        if self.crt_folder:
            logger.info('Checking the existance of test results directory in local path...')
            gen_folder = dir_fldr.pop(dir_fldr.index(self.crt_folder))
            if os.path.exists(gen_folder):
                results['Generic_folder_result'] = 'Pass'
            else:
                results['Generic_folder_result'] = 'Fail'
        else:
            results['Generic_folder_result'] = 'Not ran'

        return results

class testFolderMgmtWrapper(unittest.TestCase):

    def test_create_network_directory(self):
        network = True
        results = FolderManagement.create_results_directory_generic(network=network)

        self.assertTrue(os.path.exists(results))

    def test_create_local_directory(self):
        pass

    def test_create_network_local_directory(self):
        pass

    def test_create_generic_folder(self):
        pass

    def test_negative_generic_folder_creation(self):
        pass