"""
Unit Test module to test the conman tool wrapper

Todo:
    * Move FWPATH constant to constant file

"""

from utils.features.logger.logger import logger
from tools.toolwrapper.conman import conman
import unittest

FWPATH = r"C:\VDV10261\VDV10261_VB1B0203_WFEM01A0.bin"


class conmanTest(object):  # Todo: camelcase
    """
    Constructor method:

    :param drive_paths: Gets list of NVMe drive paths
    :type drive_paths: bool
    :param update_drive: Parameter that decide if the drives will be updated
    :type update_drive: bool
    :param drive_info: Gets drive information
    :type drive_info: bool
    """

    def __init__(self, drive_paths=False, update_drive=False, drive_info=False):
        self.drive_paths = drive_paths
        self.update_drive = update_drive
        self.drive_info = drive_info

    def drivePaths(self):
        """
        Returns all NVMe drive paths

        :return: A list of all NVMe drive paths
        """
        return conman.get_nvme_drive_paths()

    def updateDrive(self):
        """
        Updates drive's fw with reset

        :return: True if the fw was updated successfully
        """

        for drive_path in conman.get_nvme_drive_paths():
            if not conman.firmware_update(drive_path, FWPATH):
                logger.debug('Firmware update failed on drive {}'.format(drive_path))
        logger.debug('Firmware updated successfully in all drives...')
        return True

    def driveInfo(self):
        """
        Gets NVMe drive paths

        :return: True if the command was able to run the command successfully
        """
        for drive_path in conman.get_nvme_drive_paths():
            drive_info = conman.get_drive_info(drive_path)
            logger.debug('Drive info for {0}: {1}'.format(drive_path, drive_info))
            print('\nDrive info for {0}: {1}'.format(drive_path, drive_info))
        return True

    def run(self):
        """
        Runs the function if their corresponding attribute equals true

        :return: Todo: Define this method correctly
        """
        if self.drive_paths:
            print(self.drivePaths())
        if self.update_drive:
            print(self.updatePrive())
        if self.drive_info:
            print(self.driveInfo())


class TestConmanWrapper(unittest.TestCase):
    """
    Class that will test the conman wrapper functions

    """

    def test_get_drive_info_non_zero(self):
        """
        Test passes if the command that gets the drive information differs from 0

        :return: assert if get drive info differs from
        """
        drive = conman.get_nvme_drive_paths()
        b = conman.get_drive_info(drive[0])
        assert b != 0

    def test_get_drive_info_empty_dict(self):
        pass

    def test_get_nvme_drive_paths_empty_list(self):
        pass

    def test_get_nvme_drive_paths_replace_drive_path_bad(self):
        pass

    def test_firmware_update_fw_path_not_exist(self):
        pass

    def test_firmware_update_invalid_drive_path(self):
        pass

    def test_firmware_update_host_drive(self):
        pass
