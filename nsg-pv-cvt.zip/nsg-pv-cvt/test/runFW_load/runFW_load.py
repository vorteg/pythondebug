"""
Runner that instantiates a FW_load object and calls the run() function from the parent class AppBase
"""

import argparse

from test_lib.fw_load.fw_load import Fw_load
from utils.features.logger.logger import logger


def main():
    """
    :param duration: Parameter needed for the dummy test to run
    :type duration: string
    :raises: Logger.error if the dummy test fails
    """
    parser = argparse.ArgumentParser(description='Fw up/down & sidegrade')
    parser.add_argument('-t', '--duration', type=str, help='Enter desired duration in hours.')
    parser.add_argument('-fw', '--firmware', type=str, help='FW binary file')

    args,remainingArgs = parser.parse_known_args()
    print(args)

    if args.duration:
        try:
            test = Fw_load(firmware=args.firmware)
            test.run()
        except Exception as e:
            logger.error("Fail test error_code: ", e, exc_info=True)
    else:
        print("Fail")


if __name__ == "__main__":
    main()
