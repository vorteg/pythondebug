"""
Runner that instantiates a DummyTest object and calls the run() function from the parent class appBase
"""

import argparse
import os


from test_lib.dummyTest.dummyTest import DummyTest
from utils.features.logger.logger import logger


def main():
    """
    :param duration: Parameter needed for the dummy test to run
    :type duration: string
    :raises: Logger.error if the dummy test fails
    """

    parser = argparse.ArgumentParser(description='Fw up/down & sidegrade')
    parser.add_argument('-t', '--duration', type=str, help='Enter desired duration in hours.')
    args, remaining_options = parser.parse_known_args()

    logger.info("All argumets parsed from PVT to Test: {}, {}".format(args,remaining_options))
    print("All argumets parsed from PVT to Test: {}, {}".format(args,remaining_options))

    try:
        test = DummyTest(duration=args.duration)
        test.run()
    except Exception as e:
        logger.error(" Fail test error_code: ", e, exc_info=True)


if __name__ == "__main__":
    main()
