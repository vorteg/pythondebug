import json
import os

from utils.features.Settings import Settings
from pathlib import Path, PureWindowsPath


def create_test_report(test_name, test_config, status, next_steps):
    test_report = Path(os.path.abspath('../../Results/test_report.json'))
    if Settings.is_windows():
        PureWindowsPath(test_report)

    test_report_data = {}
    test_report_data["test_name"] = test_name
    test_report_data["test_config"] = test_config
    test_report_data["status"] = status
    test_report_data["next_steps"] = next_steps
    with open(test_report, 'w') as outfile:
        json.dump(test_report_data, outfile)
