#
# INTEL CONFIDENTIAL
# Copyright 2020 Intel Corporation All Rights Reserved.
# The source code contained or described herein and all documents related
# to the source code ("Material") are owned by Intel Corporation or its
# suppliers or licensors. Title to the Material remains with Intel Corporation
# or its suppliers and licensors. The Material contains trade secrets and
# proprietary and confidential information of Intel or its suppliers and
# licensors. The Material is protected by worldwide copyright and trade secret
# laws and treaty provisions. No part of the Material may be used, copied,
# reproduced, modified, published, uploaded, posted, transmitted, distributed,
# or disclosed in any way without Intel's prior express written permission.
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#

__author__ = 'GDC Test Dev'
__copyright__ = "Copyright 2020, Intel Corporation"


from utils.features.FolderManagement import  FolderManagement
import os, logging, json, time
from utils.features.logger.logger import logger

PRE_SYSTEM_REPORT = 'system_pre_report.json'
POST_SYSTEM_REPORT = 'system_post_report.json'


class FolderUtils(object):


    def __init__(self):
        """
        Constructor method: Defines if a test directory is already crated, it needs to be passed as an argument,
        for testing purposes has been declared on this constructor.
        """
        self.created_test_directory = False


    def _create_results_directory_for_test_local(self, results_directory_timestamp_local=None, test_name=None,
                                                     create_results_dir=False):
        """
        Creates results directory locally Test_timestamp
        :param results_directory_timestamp_local: Starting location for results directory
        :type: String
        :param test_name: Is the variable to create results directory name
        :type: String
        :param create_results_dir: Creates a brand new results directory for a new group of tests. Used for ConfigTest
        :type create_results_dir: Bool
        :return: The path of the local test results directory
        """
        # if the user doesn't specify starting location
        if not results_directory_timestamp_local:
            # grab the latest located in local
            # results_directory_timestamp_local = FolderManagement.get_results_directory_timestamp_local()
            pass

        if not test_name:
            test_name = FolderManagement.camel_case_to_snake_case(name=self.__class__.__name__)
        else:
            test_name = FolderManagement.camel_case_to_snake_case(name=test_name)

        # if we are unable to grab it, create one
        if results_directory_timestamp_local is None or create_results_dir:
            # results_directory_timestamp_local = FolderManagement.create_results_directory_timestamp_local()
            pass

        current_timestamp = time.strftime('%m-%d-%y__%Hh-%Mm-%Ss')
        results_directory_timestamp_test_local = os.path.join(results_directory_timestamp_local,
                                                                  test_name + '_' + current_timestamp)

        os.mkdir(results_directory_timestamp_test_local)
        return results_directory_timestamp_test_local


    def initialize_variables(self, test_name=None):
        """
        If local results directory is not found the create new directory. Handling log statements
        :param test_name: Is the variable to create results directory name
        :type test_name: String
        :return: The path of the local test results directory
        """

        self.results_directory_local = FolderManagement.create_results_directory_generic(local=True)
        if not self.created_test_directory:
            if self.results_directory_local and os.path.exists(self.results_directory_local):
                # create a location in that directory, and store results there
                self.results_directory_local = self._create_results_directory_for_test_local(
                    results_directory_timestamp_local=self.results_directory_local, test_name=test_name)
            else:
                # Create local directory if not passed in
                self.results_directory_local = self._create_results_directory_for_test_local(test_name=test_name)
                # Change working directory to local results directory
        os.chdir(self.results_directory_local)
        self.test_name = FolderManagement.camel_case_to_snake_case(name=test_name)
        # create debug logs.. will log every statement and store in debug.log
        fmt_summary = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        fmt_debug = '%(asctime)s - %(name)s - line %(lineno)d - %(levelname)s - %(message)s'

        # add fileHandler for debug that will capture everything. Stored in debug.log
        if "debug" not in [handler.name for handler in logging.getLogger().handlers]:
            debug_file_handler = logging.FileHandler(filename='debug.log')
            debug_file_handler.setFormatter(logging.Formatter(fmt_debug))
            debug_file_handler.setLevel(level=logging.DEBUG)
            debug_file_handler.set_name("debug")
            logging.getLogger().addHandler(debug_file_handler)

        logger.info("Test running in directory: {}".format(os.getcwd()))
        self.stats_dir = os.path.join(os.getcwd(), "stats")
        self.triage_dir = os.path.join(os.getcwd(), "triage")

        return self.results_directory_local


    # Generate json report
    def gen_json_report(self, info_list, json_name):

        """
        Generate json report before the test starts and second report once the test is finish.
        :param info_list: List that contains all the items to show on report
        :type info_list: list
        :param json_name: Variable used to define first report or second report to write.
        :type json_name: String
        :return: Always return true, maybe needs to add logic if generate report got fail.
        """
        if json_name == 'pre':
            TEST_REPORT = PRE_TEST_REPORT
        elif json_name == 'post':
            TEST_REPORT = POST_TEST_REPORT

        with open(TEST_REPORT, 'a+') as fp:
            json.dump(info_list, fp, indent=4, separators=(',', ':'))
        return True
