"""
Module that administers and manages the directories needed for the execution of the tests
"""

# Import Python Modules ---------------------------------------------------
import os, time, json, re
# Import PGKS Modules -----------------------------------------------------
from utils.features.Settings import Settings


# Functions definition ----------------------------------------------------

CLASSNAME_REGEX_OBJECT = re.compile('((?<=[a-z])[A-Z]|(?!^)[A-Z](?=[a-z]))')

def get_repo_location():
    """
    Returns the directory of the repository

    :return: path of the repo
    """
    tmp_path = os.getcwd()
    repo_index = tmp_path.find('nsg-pv-cvt') + 10
    results_path = tmp_path[0:repo_index]
    return results_path


def create_folder_directory_generic(folder_path):
    """
    Creates a generic folder with name and paths given

    :param folder_path: Path, directory or folder to be created
    :type folder_path: string
    :return: The complete folder's path created and an exit code indicating the process failed or was successfully completed
    """
    if not os.path.isdir(folder_path):
        os.mkdir(folder_path)
        if not os.path.exists(folder_path):
            print("Failed to create {}".format(folder_path))
            raise OSError
    return folder_path


def crt_folder(func):
    """
    Decorator that creates the test's results directory in the network or local path or both

    :param func: Decoratior will check in which paths the directory will be created
    :type func: Function
    :return: Results directory
    """
    def create_results_directory(results_directory=None, network=False, local=False, test_name=None):
        results_directory = []
        if not network and not local:
            print('Please select at least create local or network results directory')
            return func(None, False, False, None)
        elif network and not local:
            print('Skipping local path, setting network path info...')
            results_directory.append(get_results_directory_network())
            return func(results_directory, True, False, None)
        elif not network and local:
            print('Skipping network path, setting local path info...')
            results_directory.append(get_local_path())
            return func(results_directory, False, True, None)
        elif network and local:
            print('Setting local and network path info...')
            results_directory.append(get_results_directory_network())
            results_directory.append(get_local_path())
            return func(results_directory, True, True, None)

    return create_results_directory


@crt_folder
def create_results_directory_generic(results_directory=None, network=False, local=False, timestamp=None):
    """
    Creates the results directory using the decorator crt_folder

    :param results_directory: Refers to the path in which Results are being copied
    :type results_directory: string
    :param network: Uses a boolean var to set the results directory in network path or not
    :type network: bool
    :param local: Uses a boolean var to set the results directory in local path or not
    :type local: bool
    :param timestamp: Records the time the directory was created
    :type timestamp: bool
    """
    # Make directory if it doesn't exist
    for res_dir in range(len(results_directory)):
        create_folder_directory_generic(results_directory[res_dir])

    # Create results directory based on current timestamp
    if not timestamp:
        current_timestamp = time.strftime('%m-%d-%y__%Hh-%Mm-%Ss')
    else:
        current_timestamp = timestamp
    for res_dir_time in range(len(results_directory)):
        results_directory_timestamp = os.path.join(results_directory[res_dir_time], current_timestamp)
        os.mkdir(results_directory_timestamp)
        if not os.path.exists(results_directory_timestamp):
                print("Failed to create {}".format(results_directory_timestamp))
                raise OSError
    return results_directory_timestamp


def get_results_directory_network(hostname=None):
    """
    Creates the directory where the Results will be posted on the network

    :param hostname: Name of the SUT
    :type hostname: string
    :return: Networks Results directory
    """
    if hostname is None:
        hostname = Settings.get_hostname()
    json_file = open(get_locations_file(), 'r')
    locations_json = json.load(json_file)
    results = locations_json['results_directory']
    json_file.close()

    return os.path.join(get_network_path(), results, hostname)


def get_network_path():
    """
    Gets the path of the share folder or the network location

    :return: path of the network location
    """
    network = ''
    # Load JSON File
    json_file = open(get_locations_file(), 'r')
    locations_json = json.load(json_file)
    # Get Path
    if Settings.is_windows():
        network = locations_json['windows']['network']
    if Settings.is_linux():
        network = locations_json['linux']['network']

    json_file.close()
    return network


def get_local_path():
    """
    Gets the results directory path

    :return: Local results directory path
    """
    json_file = open(get_locations_file(), 'r')
    locations_json = json.load(json_file)
    results = locations_json['results_directory']
    json_file.close()
    results_directory_path = os.path.join(get_repo_location(), results)
    return results_directory_path


def get_locations_file():
    """
    Get the location file path

    :return: The path of the locations.json file
    """
    return os.path.join(get_repo_location(), 'utils', 'locations.json')


def camel_case_to_snake_case(name):
    return CLASSNAME_REGEX_OBJECT.sub(r'_\1', name).upper()


