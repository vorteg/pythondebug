"""
Modules that obtains information from the testing environment. This includes the OS, the SUT hardware, etc.
"""

from subprocess import *
import sys, socket, platform, os, re
from tools.tools import Tools

JIRA_DATA_LIST = ['TEST_NAME', 'TEST_NUMBER_OF_DRIVES', 'TEST_COMMAND_LINE', 'CTF_NODE', 'CTF_Branch', 
                    'TEST_RESULTS_DIRECTORY', 'HOSTNAME', 'SYSTEM_MODEL', 'OPERATING_SYSTEM', 'CONMAN']


def get_operating_system():
    """
    :return: Returns the operating system
    """
    return sys.platform


def command_exist(command):
    """
    Checks if system supports a program

    :param command: Program to check
    :return: Returns True if the program exists, False otherwhise
    """
    return any(os.access(os.path.join(path, command), os.X_OK) for path in os.environ["PATH"].split(os.pathsep))


def get_hostname():
    """
    :return: SUTs name
    """
    return socket.gethostname().upper()


def is_windows():
    """
    :return: True if the OS is Windows
    """
    return get_operating_system().startswith('win')


def is_windows_2008():
    """
    :return: Tue if the OS is Windows 2008
    """
    if is_windows():
        version = sys.getwindowsversion()
        if version.major == 6 and version.minor < 2:
            return True
    return False


def is_linux():
    """
    :return: True if the OS is Linux
    """
    return get_operating_system().startswith('linux')


def is_ubuntu():
    """
    :return: True if the OS is Ubuntu
    """
    os_keywords = ['UBUNTU', 'DEBIAN']
    return any(kw in platform.platform().upper() for kw in os_keywords)


def is_suse():
    """
    :return: True if the OS is SUSE
    """
    os_keywords = ['SUSE']
    return any(kw in platform.platform().upper() for kw in os_keywords)


def get_os_type(default=None):
    """
    Returs the OS type in a string form

    :param default: String that will be returned by default if OS specific type not detected
    :return: string type of the OS e.g. LINUX
    """
    if is_windows():
        os_name = 'WINDOWS'
    elif is_linux():
        os_name = 'LINUX'
    else:
        os_name = default
    return os_name


def __get_dict(command):
    """
    Collected the output of systeminfo/dmidecode for windows or linux respectively.

    :param command: 'systeminfo' for windows, 'dmidecode' for linux
    :return: parse the output of systeminfo/dmiodecode command and return it as dictionary
    """
    system_hash = {}
    sys_info = check_output(command)
    sys_info_array = str(sys_info).split(r'\r\n')
    for attribute in sys_info_array:
        attribute = attribute.strip()
        key_value_array = re.split(':\s+', attribute)
        if len(key_value_array) > 1:
            system_hash[key_value_array[0]] = key_value_array[1]
    return system_hash


def get_win_sys_info():
    """
    Parse the output of systeminfo for windows

    :return: a dictionary which contains windows system information
    """
    system_info_dict = __get_dict('systeminfo')
    win_sys_info = {}

    win_sys_info['HOSTNAME'] = system_info_dict['Host Name']
    win_sys_info['SYSTEM_MODEL'] = system_info_dict['System Model']
    win_sys_info['OS'] = system_info_dict['OS Name']

    return win_sys_info


def drives_path_dict():
    """
    Uses Conman to get path to drives in SUT

    :return: A dictionary with all drives path
    """
    drives_dict = {}
    fw_tool = Tools('conman').select_tool()
    drive_list_dict = fw_tool.get_nvme_drive_paths()
    drives_dict['Drives_Path'] = drive_list_dict
    return drives_dict


def drives_info_dict(drive_handle):
    """
    Uses Conman to get drive info through drive handler

    :param drive_handler: drive handler <\\\\.\\PHYSICALDRIVEXX>
    :return: A dictionary which contains drive info such as FW, SN, BL, status, etc.
    """
    info_dict = {}
    fw_tool = Tools('conman').select_tool()
    get_info_dict = fw_tool.get_drive_info(drive_handle)
    info_dict['Drive_Path'] = drive_handle
    info_dict['Drive_Info'] = get_info_dict
    return info_dict


def write_jira_template(test_name, results_directory, system_stats=None, inbox_driver=False,
                        comment_filename_prefix=None, return_dict=None):
    """
    Writes from a template file a jira specific template with SUT and test details for easy report when failing

    :param test_name: String name of test actually running
    :param results_directory: String of current results directory, used to save jira template
    :param system_stats: Dictionary of system information and configuration, set to none will make the function get that info
    :param inbox_driver: Bool, Set whether the SUT is using inbox driver or not
    :param comment_filename_prefix: receives a string to set a customable prefix to jira template generated
    :param return_dict: Bool, Set to True will return a dictionary with all values configured in jira template else will not
    """
    filename = 'jira_template'

    if comment_filename_prefix is None:
        comment_file = 'comment_jira_template.txt'
    else:
        comment_file = str(comment_filename_prefix) + '_comment_jira_template.txt'
    if is_windows():
        template_file = os.sep.join((os.path.expanduser(os.getcwd()).split(os.sep))[:2]) + os.sep + 'template.txt'
        comment_template_file = os.sep.join((os.path.expanduser(os.getcwd()).
                                             split(os.sep))[:2]) + os.sep + 'jira_comment_template.txt'
    else:
        template_file = os.sep+(os.sep.join(((os.path.expanduser(os.getcwd()).split(os.sep))[1:])[:2]))+os.sep + \
                        'template.txt'
        comment_template_file = os.sep + (os.sep.join(((os.path.expanduser(os.getcwd()).split(os.sep))[1:])[:2])) \
                                       + os.sep + 'jira_comment_template.txt'

    # Test info recopilation
    test_data = {}
    test_data['TEST_NAME'] = test_name

    fw_tool = Tools('conman').select_tool()
    test_data['TEST_NUMBER_OF_DRIVES'] = str(len(fw_tool.get_nvme_drive_paths()))

    test_data['TEST_COMMAND_LINE'] = ' '.join(sys.argv)

    try:
        ctf_hash = check_output("git rev-parse HEAD", shell=True).strip()
        ctf_release = check_output("git describe --tags", shell=True).strip()
        test_data['CTF_NODE'] = str(ctf_hash) + " " + str(ctf_release)
    except CalledProcessError as e:
        test_data['CTF_NODE'] = 'UNKNOWN'
        return False

    try:
        ctf_hash = check_output("git rev-parse --abbrev-ref HEAD", shell=True).strip()
        ctf_release = check_output("git describe --tags", shell=True).strip()
        test_data['CTF_Branch'] = str(ctf_hash) + " " + str(ctf_release)
    except CalledProcessError as e:
        test_data['CTF_Branch'] = 'UNKNOWN'
        return False

    test_data['TEST_RESULTS_DIRECTORY'] = results_directory

    # SUT info recopilation
    if not system_stats:
        sys_stats = get_win_sys_info()
    else:
        sys_stats = system_stats
    test_data['HOSTNAME'] = sys_stats['HOSTNAME']
    test_data['SYSTEM_MODEL'] = sys_stats['SYSTEM_MODEL']

    # Configuration info recopilation
    test_data['OPERATING_SYSTEM'] = sys_stats['OS']

    # Populating jira template with test_data info
    data = []
    with open(template_file, 'r') as fp:
        lines = (line.rstrip() for line in fp)
        #data = [test_data[JIRA_DATA_LIST[index + 1]] if JIRA_DATA_LIST[index + 1] in line else line for line in lines]
        for line in lines:
            data.append(line)
            for index in range(len(JIRA_DATA_LIST)):
                if JIRA_DATA_LIST[index] in line:
                    concurrence = line.replace(JIRA_DATA_LIST[index], test_data[JIRA_DATA_LIST[index]], 1)
                    data.remove(line)
                    data.append(concurrence)
    with open(comment_file, 'w') as tf:
        for container in data:
            tf.write(container + '\n')
    tf.close()
    return True


if __name__ == "__main__":
    print(__get_dict('systeminfo'))