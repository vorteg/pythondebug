"""
Module that manages the test's logs.
"""

# Import Python Modules ---------------------------------------------------
import logging
import os
from pathlib import Path, PureWindowsPath
# Import PGKS Modules -----------------------------------------------------
from utils.features.Settings import Settings
# Global variables
NAME ='TestGen'
PATHFILE =  r'C:\nsg-pv-cvt\Results\app.log'
"""
if Settings.is_windows():
    PureWindowsPath(PATHFILE)
    print("Hola soy el logger path : ",PATHFILE)
"""
#Classes -------------------------------------------------------------------
logging.basicConfig(level=logging.DEBUG,
                        filename=PATHFILE,
                            filemode='w',
                                format='%(asctime)s - %(name)s - %(levelname)s- %(message)s',
                                    datefmt='%d-%b-%y %H:%M:%S')
logging.debug('%s This will get logged',NAME)
logging.warning('This will get logged to a file')

logger = logging.getLogger(__name__)

if __name__ == '__main__':
    logger.warning('Testing how to get Result path from pvt')
