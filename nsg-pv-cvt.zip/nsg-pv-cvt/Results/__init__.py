"""
The Results directory will hold the logs collected during the Test flow. This includes systems stats and drive stats,
commands executed, errors found, etc.
"""