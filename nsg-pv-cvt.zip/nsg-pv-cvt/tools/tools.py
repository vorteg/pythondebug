"""
Class that selects which tool is going to be used.

Todo:
    * Move PATHMODULE constant to constant file

"""

import importlib

PATHMODULE = 'tools.toolwrapper'  # TODO WATCH OUT FROM WICH FOLDER COMES AS THIS CALL CAN CHANGE THE PATH


class Tools():
    """
    Constructor method:

    :param tool: Tool chosen
    :type tool: string
    """

    def __init__(self, tool):
        self.tool_name = tool

    def select_tool(self):
        """
        Function that works as a tool selector

        :return: Tool wrapper of the tool selected
        """
        t = self.tool_name
        module = importlib.import_module(PATHMODULE + '.' + t + '.' + t)

        return module


if __name__ == '__main__':

    a = Tools('conman')
    b = a.select_tool()
    b.run_test()
