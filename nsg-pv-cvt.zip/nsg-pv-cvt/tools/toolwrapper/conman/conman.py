"""
Conman tool wrapper. Runs Conman commands.

Todo:
    * Move constant windows path to const list

"""
import re
import subprocess

from test_ops.drive_ops.raid_fs_control import Partition
from utils.features.logger.logger import logger

WINDOWS_PATH = r'C:\\Program Files\\Intel\\Intel(R) SSD Configuration Manager\\issdcm.exe'


def run_test():
    """
    Dummy function that simulates the execution of the "list_disk" conman command

    :return: '\\\\.\\PHYSICALDRIVE1'
    """
    print("Getting drive info from conman tool")
    logger.info("ConMan was executed")
    list_drive_paths = ['\\\\.\\PHYSICALDRIVE1']
    return list_drive_paths


def fw_up_test(drive):
    """
    Dummy function that simulates the upgrade of a drive's firmware

    :param drive: drive path of the drive to simulate the upgrade
    :return: a printed statment that the fw was updated successfully
    """
    print('-----------------------------------------')
    print('\nUpdating Drive')
    return print("\nDrive with path ", drive, "\nfw updated, Successfully")


def run(*args, **kwargs):
    """
    Function that executes the given conman commands with the given parameters

    :param args: Command to execute with respective parameters
    :type args: string
    :param kwargs: Optional parameters with keywords
    :return: stdout and error code of the executed command
    """
    parameters = [WINDOWS_PATH] + list(args)
    logger.info('Command: {0}'.format(' '.join(parameters)))
    process = subprocess.Popen(parameters, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = process.communicate()
    error_code = process.returncode
    pid = process.pid
    logger.info('stdout: {0}, stderr: {1}'.format(stdout, stderr))
    logger.info('issdcm ran with process ID {0}.'.format(pid))
    logger.info('issdcm finished with error code {0}'.format(error_code))
    return stdout, error_code


def get_nvme_drive_paths():
    """
    Gets all of the NVMe drive paths using conman

    :return: List of NVMe drive paths
    """
    drive_paths = []
    nvme_drive_paths = []
    out, error_code = run(*['-drive_list'])
    lines = out.splitlines()
    for line in lines:
        conman_group = re.search('.*Path:.*\|(.*)\|', str(line))
        if not conman_group:
            conman_group = re.search('.*Path\s*:(.*)', str(line))
        if conman_group:
            drive_paths.append(conman_group.group(1).strip()[:-1])
    if drive_paths:
        for drive_path in drive_paths:
            drive_path = drive_path.replace(r'\\\\.\\', '\\\\.\\')
            out = get_controller(drive_path)
            lines = out.splitlines()
            for line in lines:
                status_group = re.search('Status:(.*)', str(line))
                if status_group:
                    if not re.search('.*The selected drive does not support this feature.', status_group.group(1)):
                        if not Partition.is_host(drive_path):
                            nvme_drive_paths.append(drive_path)
                        else:
                            logger.debug('{} is host'.format(drive_path))
    return nvme_drive_paths


def get_controller(drive_handle):
    """
    Gets conman controller info

    :param drive_handle: drive path of the drive to get controller info
    :type drive_handle: string
    :return: stdout of command executed to get controller info
    """
    logger.info('Running Conman controller command on drive {0}'.format(drive_handle))
    stdout, error_code = run(*['-drive_path', drive_handle, '-identify', '-controller'])
    return stdout


def firmware_update(drive_handle, fwfile):
    """
    Applies firmware update with reset

    :param drive_handle: drive path of drive to update FW
    :type drive_handle: string
    :param fwfile: path to binary fw file
    :type fwfile: string
    :return: returns error code if it equals 0
    """
    logger.info("Applying update on {0} with {1}".format(drive_handle, fwfile))
    stdout, error_code = run(*['-drive_path', drive_handle, '-firmware_update', fwfile, '-force'])
    return error_code == 0


def get_drive_info(drive_handle):
    """
    Gets drive information

    :param drive_handle: the drive path to run conman on
    :return: drive information
    """
    ret, error_code = run(*['-drive_path', drive_handle])
    ret = str(ret).replace('|', '')
    drive_info = {}
    for line in str(ret).split(r'\r\n'):
        group_info = re.search(r"([\w\s]+):\s*([\w\s\/\.\(\)]+)", line)
        try:
            drive_info[group_info.group(1).strip(' ')] = group_info.group(2)
        except AttributeError:
            pass

    return drive_info

## \brief get smart
#  \param drive_handle The drive path to run conman on
#  \return The smart output of the drive as a string
def get_smart_info(drive_handle):
    ret = run(*['-drive_path', drive_handle, '-get_log', '2'])
    ret = str(ret).replace('|', '')
    smart_info = {}
    for line in str(ret).split(r'\r\n'):
        group_info = re.search(r"([\w\s]+):\s*([\w\s\/\.\(\)]+)", line)
        try:
            smart_info[group_info.group(1).strip(' ')] = group_info.group(2)
        except AttributeError:
            pass
    return smart_info


def get_smart_values(drive_handle):
    smart_values_dict = get_smart_info(drive_handle)
    smart_values = {}

    smart_values['FIRMWARE'] = smart_values_dict['Firmware']
    smart_values['SECTOR_SIZE'] = smart_values_dict['SectorDataSize']
    smart_values['CRIT_WARNINGS'] = smart_values_dict['Critical Warnings']
    smart_values['TEMP'] = smart_values_dict['Celsius']
    smart_values['POWER_CYCLES'] = smart_values_dict['Power Cycles']
    report_smart_values = {}
    report_smart_values['Drive Path'] = drive_handle
    report_smart_values['Smart Values'] = smart_values
    return report_smart_values

def get_version():
    stdout, exit_code = run(*['-v'])
    lines = stdout.splitlines()
    x = lines.index('Intel(R) SSD Configuration Manager')
    if x != '':
        return lines[x+1]
    return False


if __name__ == "__main__":
    print(get_nvme_drive_paths())
