"""
toolTest wrapper. Runs toolTest commands.

"""

from utils.features.logger.logger import logger




def run_test():
    """
    Dummy function that simulates the execution of the "list_disk" conman command

    :return: '\\\\.\\PHYSICALDRIVE1'
    """
    print("Getting drive info from toolTest")
    logger.info("Tool Test was executed")
    list_drive_paths = ['\\\\.\\PHYSICALDRIVE1']
    return list_drive_paths


def fw_up_test(drive):
    """
    Dummy function that simulates the upgrade of a drive's firmware

    :param drive: drive path of the drive to simulate the upgrade
    :return: a printed statment that the fw was updated successfully
    """
    print('-----------------------------------------')
    print('\nUpdating Drive')
    return print("\nDrive with path ", drive, "\nfw updated, Successfully")

def get_nvme_drive_paths():
    """
    Dummy function that simulates the execution of the "list_disk" conman command

    :return: '\\\\.\\PHYSICALDRIVE1'
    """
    print("Getting drives from toolTest")
    logger.info("Tool Test was executed")
    list_drive_paths = ['\\\\.\\PHYSICALDRIVE0','\\\\.\\PHYSICALDRIVE1','\\\\.\\PHYSICALDRIVE2']
    return list_drive_paths

def get_nvme_drive_serial():
    """
    Dummy function that simulates the execution of the "list_disk" conman command

    :return: '\\\\.\\PHYSICALDRIVE1'
    """
    print("Getting drive SerialNumber from toolTest")
    logger.info("Tool Test was executed")
    list_drive_paths = ['\\\\.\\PH78738109n21','\\\\.\\PH78738109n24','\\\\.\\PH78738109n28']
    return list_drive_paths

def get_nvme_drive_id():
    """
    Dummy function that simulates the execution of the "list_disk" conman command

    :return: '\\\\.\\PHYSICALDRIVE1'
    """
    print("Getting drive id from toolTest")
    logger.info("Tool Test was executed")
    list_drive_paths = ['\\\\.\\0x000212123','\\\\.\\0x000212124','\\\\.\\0x000212125']
    return list_drive_paths

def drives_path_dict():
    """
    Dummy function that simulates the execution of the "drives_dict" conman command

    :return: '\\\\.\\PHYSICALDRIVE1'
    """
    drives_dict = {}
    print("Getting drive info from toolTest")
    logger.info("Tool Test was executed")
    drive_list_dict = '\\\\.\\PHYSICALDRIVE1'
    drives_dict['Drives_Path'] = drive_list_dict
    return drives_dict

def get_smart_values(drive_path):
    return print(drive_path,"smart counters 0x000212123")

def get_drive_info(drive_path):
    drives_dict = {
    '\\\\.\\PHYSICALDRIVE0':{'SerialNumber': 'SN000212123N56',
    'Firmware': 'FW23' ,
    'DeviceStatus': 'Healthy',
    'Index' : '3',
    'SectorDataSize' :'512'
    },'\\\\.\\PHYSICALDRIVE1':{'SerialNumber': 'SN000212123N56',
    'Firmware': 'FW23' ,
    'DeviceStatus': 'Healthy',
    'Index' : '3',
    'SectorDataSize' :'256'
    },
    '\\\\.\\PHYSICALDRIVE2':{'SerialNumber': 'SN000212123N56',
    'Firmware': 'FW23' ,
    'DeviceStatus': 'FAIL',
    'Index' : '3',
    'SectorDataSize' :'4k'
    }}
    return drives_dict
if __name__ == '__main__':
    dic = get_drive_info('\\\\.\\PHYSICALDRIVE0')
    print(dic['\\\\.\\PHYSICALDRIVE0']['SerialNumber'])
    #print (dic['SerialNumber'])
