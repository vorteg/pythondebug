"""
The Drive Handler class creates a drive object with its characteristics as attributes.
These characteristics are

        * tool
        * mode
        * serial
        * fw_version
        * quarch
        * status
        * drive_path
        * drive_index
        * sector_size

"""
from tools.tools import Tools


class DriveHandler:
    """
    Constructor method:

    :param tool: The tool that will be used to get all of the drive's information
    :type tool: string
    :param mode: The way that the drive will be identified, either drive handle, index or serial number
    :type mode: basestring
    :param serial: Drive's serial number
    :type serial: string
    :param fw_version: Drives' FW version
    :type fw_version: string
    :param quarch: Drive's quarch port. None if it does not have one.
    :type quarch: int
    :param status: Drive's health status
    :type status: string
    :param drive_path: Drive's drive path
    :type drive_path: string
    :param drive_index: Drive's drive index. None if the tool selected cannot obtain this information.
    :type drive_index: int
    :param sector_size: Drive's current sector size
    :type sector_size: string
    """

    def __init__(self, tool, mode=None, *args):
        self.tool = tool
        self.mode = mode
        self.serial = None
        self.fw_version = None
        self.quarch = None
        self.status = None
        self.drive_path = None
        self.drive_index = "1"
        self.sector_size = None

    def __get_tool(self):
        """
        :return: object tool
        """
        tl = Tools(self.tool).select_tool()
        return tl

    def __get_drive_obj(self):
        """
        :return: A single drive object
        """
        tool =self.__get_tool()
        drive_list = tool.get_nvme_drive_paths()
        attr_tool_dict = tool.get_drive_info(drive_list[0])  # TODO: Remove harcoded index
        # map(method, drive_list)
        self.serial = attr_tool_dict['SerialNumber']
        self.fw_version = attr_tool_dict['Firmware']
        self.status = attr_tool_dict['DeviceStatus']
        self.drive_path = drive_list[0]  # TODO dict is empty on this parameter
        self.drive_index = attr_tool_dict['Index']
        self.sector_size = attr_tool_dict['SectorDataSize']
        # test branch

    def run_drive_handler_object(self):
        """
        Non static function that can be called with the drive object. Calls the static function to create the drive
        object

        :return: Drive object
        """
        #drv_obj = DriveHandler(self.tool)
        drv_obj =self.__get_drive_obj()
        attrs = vars(drv_obj)
        print(', '.join("%s: %s" % item for item in attrs.items()))
        return drv_obj

    def drives_path_dict():
        """
        Uses Conman to get path to drives in SUT

        :return: A dictionary with all drives path
        """
        drives_dict = {}
        tool =self.__get_tool()
        drive_list_dict = tool.get_nvme_drive_paths()
        drives_dict['Drives_Path'] = drive_list_dict
        return drives_dict


if __name__ == '__main__':
    disk = DriveHandler('conman').run_drive_handler_object()
    print(disk.status, disk.drive_path)
