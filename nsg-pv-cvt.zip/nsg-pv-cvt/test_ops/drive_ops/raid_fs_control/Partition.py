"""
Modules that obtains and set information from/to the DUTs. Includes raid info, partitions, filesystems, etc.
"""

__copyright__ = "Copyright 2020, Intel Corporation"

from utils.features.Settings import Settings
from test_ops.drive_ops import Diskpart
from utils.features.logger.logger import logger


def __is_host_windows(block_device, serial=None):
    """
    Determines if given block device is a host on a Windows system
    
    :param block_device: Drive block device
    :param serial: serial drive
    :return: True if block device is the OS disk. False otherwise
    """
    if not block_device:
        return False
    # Check diskpart details
    disk_dict = Diskpart.get_disk_dict(block_device.strip('\\\\.\\PHYSICALDRIVE'))
    if disk_dict:
        if 'Boot Disk' in disk_dict:
            if 'Yes' == disk_dict['Boot Disk']:
                return True

    return False


def __is_host_linux(block_device, serial=None):
    """
    Determines if given block device is a host on a Linux system
    
    :param block_device: Drive block device
    :param serial: serial drive
    :return: True if block device is the OS disk. False otherwise
    """
    pass
    return False


def is_host(block_device, serial=None):
    """
    Determines if given block device is a host
    
    :param block_device: Drive block device
    :param serial: serial drive
    :return: True if block device is the OS disk. False otherwise
    """
    return __is_host_windows(block_device, serial) if Settings.is_windows() else __is_host_linux(block_device, serial)
