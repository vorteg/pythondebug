"""
Diskpart tool wrapper. Runs Diskpart commands.
"""

import os
import subprocess
import uuid

from utils.features.logger.logger import logger


def run_tool(**kwargs):
    """
    Runs Diskpart

    :param kwargs: Optional additional arguments with keywords
    :return: stdout and error code from diskpart command
    """
    # Create tmp script file
    command_list = kwargs.pop('script', [])
    script_file = 'diskpart_{0}.txt'.format(uuid.uuid4())
    with open(script_file, 'w') as script:
        for command in command_list:
            script.write(command + '\n')

    logger.info('Running diskpart /s %s', script_file)
    logger.debug('Diskpart commands - %s', command_list)
    process = subprocess.Popen(['diskpart', '/s', script_file], stdout=subprocess.PIPE)
    stdout = process.communicate()[0]
    error_code = process.returncode
    logger.info('diskpart finished with error code %s', error_code)

    # Remove tmp script file
    os.remove(script_file)

    return stdout, error_code


def get_disk_dict(disk_index):
    """
    Gets disk details

    :param disk_index: The index of the disk to get info :return: A dictionary with the following disk information:

    'Disk ID', 'Type', 'Status', 'Path', 'Target', 'LUN ID', 'Location Path', 'Read-only', 'Boot Disk',
    'Pagefile Disk', 'Hibernation File Disk', 'Crashdump Disk', 'Clustered Disk'

    """
    param_list = ['Disk ID', 'Type', 'Status', 'Path', 'Target', 'LUN ID', 'Location Path', 'Read-only', 'Boot Disk',
                  'Pagefile Disk', 'Hibernation File Disk', 'Crashdump Disk', 'Clustered Disk']
    disk_dict = {}
    logger.info('Getting disk dictionary...')
    output = run_tool(script=['select disk {0}'.format(disk_index), 'detail disk'])[0]
    if output:
        disk_dict['Index'] = disk_index
        disk_dict['Volumes'] = []
        for line in output.splitlines():
            if 'Volume' in str(line) and 'Volume ###' not in str(line):
                if str(line).split().index('Volume') > 1:
                    continue
                if '*' in str(line):
                    disk_dict['Volumes'].append(str(line).split()[2])
                else:
                    disk_dict['Volumes'].append(str(line).split()[1])
            for param in param_list:
                if str(param) == str(line).split(':')[0].strip():
                    disk_dict[param] = str(line).split(':')[-1].strip()
                    break
    logger.info('Disk dictionary - {}'.format(disk_dict))
    return disk_dict

