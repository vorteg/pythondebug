"""
The Drive Dummy class creates a drive object with its characteristics as attributes.
These characteristics are

        * tool
        * mode
        * serial
        * fw_version
        * quarch
        * status
        * drive_path
        * drive_index
        * sector_size

"""
from tools.tools import Tools


class DriveDummy:
    """
    Constructor method:

    :param tool: The tool that will be used to get all of the drive's information
    :type tool: string
    :param mode: The way that the drive will be identified, either drive handle, index or serial number
    :type mode: basestring
    :param serial: Drive's serial number
    :type serial: string
    :param fw_version: Drives' FW version
    :type fw_version: string
    :param quarch: Drive's quarch port. None if it does not have one.
    :type quarch: int
    :param status: Drive's health status
    :type status: string
    :param drive_path: Drive's drive path
    :type drive_path: string
    :param drive_index: Drive's drive index. None if the tool selected cannot obtain this information.
    :type drive_index: int
    :param sector_size: Drive's current sector size
    :type sector_size: string
    """

    def __init__(self, tool='toolTest', mode=None, *args):
        self.tool = tool
        self.mode = mode
        self.serial = None
        self.fw_version = None
        self.quarch_slot = None
        self.status = None
        self.drives_path = None
        self.drive_path = None
        self.drive_index = "1"
        self.sector_size = None

    def __get_tool(self):
        """
        :return: object tool
        """
        tl = Tools(self.tool).select_tool()
        return tl



    def __get_drive_direction(self):
        tool = self.__get_tool()
        mode = self.mode
        if mode == None:
            return tool.get_nvme_drive_paths()
        elif mode == 'serial':
            return tool.get_nvme_drive_serial()
        else:
            return tool.get_nvme_drive_id()



    def __get_drive_obj(self, slot):  # TODO Define parameters of a drive
        """
        :return: A list of all NVMe drive objects
        """
        drive_slot = slot
        tool  = self.__get_tool()
        attr_tool_dict = tool.get_drive_info(drive_slot)
        disk = DriveDummy()
        print(drive_slot)
        disk.serial = attr_tool_dict[drive_slot]['SerialNumber']
        disk.fw_version = attr_tool_dict[drive_slot]['Firmware']
        disk.status = attr_tool_dict[drive_slot]['DeviceStatus']
        disk.drive_path = drive_slot  # TODO dict is empty on this parameter
        disk.drive_index = attr_tool_dict[drive_slot]['Index']
        self.sector_size = attr_tool_dict[drive_slot]['SectorDataSize']
        print("Drive Dummy object created: disk{}".format( disk))
        return disk

    def __get_drives_obj_list(self):
        drive_list = self.__get_drive_direction()
        self.drives_path = drive_list
        drives=[]

        for drive in drive_list:
            disk = self.__get_drive_obj(drive)
            drives.append(disk)
        print(drives)
        return drives

    def drive_sanity_check(self):
        drives = self.__get_drives_obj_list()
        slt = len(drives) 
        print("the slt value is {} befor inside to FOR".format(slt))
        while (slt is not 0):
            slt -= 1 
            print ("slt value is {} in each iteration".format(slt))
            if drives[slt].status is not 'Healthy':
                print("Critical fail check physical drive: {}".format(drives[slt].drive_path))
                 




    def run(self):
        """
        Non static function that can be called with the drive object. Calls the static function to create the drive
        object list

        :return: Drive object list
        """
        drives = self.__get_drives_obj_list()
        print("\nDrives object was created\n",self.drives_path)
        return drives



if __name__ == '__main__':
    DriveDummy().drive_sanity_check()
    #disks = DriveDummy('toolTest').run()
    #d1 = disks[0]
    #print(d1.status)

    #print(disk.status, disk.drive_path)
